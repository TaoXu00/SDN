package org.sdn.dataType;

public enum msgType {
  Aggregate,
  Bandwidth,
  AggregateReset,
  BandwidthReset;
}
