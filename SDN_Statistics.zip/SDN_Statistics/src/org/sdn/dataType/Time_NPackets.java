package org.sdn.dataType;

public class Time_NPackets {
	long time;
	long NPackets;
	
	public long getTime() {
		return time;
	}
	public void setTime(long time) {
		this.time = time;
	}
	public long getNPackets() {
		return NPackets;
	}
	public void setNPackets(long nPackets) {
		NPackets = nPackets;
	}
	

}
