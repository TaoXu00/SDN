package org.sdn.dataType;

public class DPID_TIME {
 String DPID;
 long UnixTime;

 public String getDPID() {
	return DPID;
}
public void setDPID(String dPID) {
	DPID = dPID;
}
public long getUnixTime() {
	return UnixTime;
}
public void setUnixTime(long unixTime) {
	UnixTime = unixTime;
}

 
}
