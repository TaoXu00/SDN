#!/bin/bash
cd /home/xu/floodlight
java -jar target/floodlight.jar &
#cd /home/xu/mininet/custom/
#echo '123' | sudo -kS ./mytopology.py 
